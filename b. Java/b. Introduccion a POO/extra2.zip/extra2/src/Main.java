import Servicio.ServEnt;

public class Main {
    public static void main(String[] args) {
        ServEnt menuServ = new ServEnt();
        menuServ.menu();
    }
}
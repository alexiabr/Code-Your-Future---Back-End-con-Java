package Entidad;

public class Cuadrado {
        private Double lado;

        public Cuadrado() {
        }

        public Double getLado() {
            return lado;
        }

        public void setLado(Double lado) {
            this.lado = lado;
        }

        public Cuadrado(Double lado) {
            this.lado = lado;
        }
}



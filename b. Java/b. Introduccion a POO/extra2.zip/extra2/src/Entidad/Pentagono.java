package Entidad;

public class Pentagono {
    private Double lado;
    private Double apotema;

    public Pentagono() {
    }

    public Double getLado() {
        return lado;
    }

    public void setLado(Double lado) {
        this.lado = lado;
    }

    public Double getApotema() {
        return apotema;
    }

    public void setApotema(Double apotema) {
        this.apotema = apotema;
    }

    public Pentagono(Double lado, Double apotema) {
        this.lado = lado;
        this.apotema = apotema;
    }
}

package Entidad;

public class Rombo {
    private Double lado;
    private Double dmayor;
    private Double dmenor;

    public Rombo() {
    }

    public Double getLado() {
        return lado;
    }

    public void setLado(Double lado) {
        this.lado = lado;
    }

    public Double getDmayor() {
        return dmayor;
    }

    public void setDmayor(Double dmayor) {
        this.dmayor = dmayor;
    }

    public Double getDmenor() {
        return dmenor;
    }

    public void setDmenor(Double dmenor) {
        this.dmenor = dmenor;
    }

    public Rombo(Double lado, Double dmayor, Double dmenor) {
        this.lado = lado;
        this.dmayor = dmayor;
        this.dmenor = dmenor;
    }


}


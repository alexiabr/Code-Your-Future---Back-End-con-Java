package Entidad;

public class Hexagono {

    private Double lado;
    private Double apotema;

    public Hexagono() {
    }

    public Double getLado() {
        return lado;
    }

    public void setLado(Double lado) {
        this.lado = lado;
    }

    public Double getApotema() {
        return apotema;
    }

    public void setApotema(Double apotema) {
        this.apotema = apotema;
    }

    public Hexagono(Double lado, Double apotema) {
        this.lado = lado;
        this.apotema = apotema;
    }
}

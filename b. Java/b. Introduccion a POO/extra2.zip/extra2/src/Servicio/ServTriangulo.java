package Servicio;

import Entidad.Triangulo;

import java.util.Scanner;

public class ServTriangulo {
    Scanner leer = new Scanner(System.in);

    public Triangulo crearTriangulo(){
        Triangulo c = new Triangulo();

        System.out.println("ingrese el base: ");
        c.setBase(leer.nextDouble());
        System.out.println("ingrese el altura: ");
        c.setAltura(leer.nextDouble());
        return c;
    }

    public void area(Triangulo c){
        System.out.println("el area del triangulo es "+ (c.getBase() * c.getAltura())/2);
    }

    public void perimetro(Triangulo c){
        System.out.println("El perimetro es " + (c.getBase()*3 ));
    }
}

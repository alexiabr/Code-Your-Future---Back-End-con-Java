package Servicio;

import Entidad.Circulo;
import Entidad.Cuadrado;
import Entidad.Rectangulo;
import Entidad.Triangulo;

import java.util.Scanner;

public class ServEnt {

    Scanner leer = new Scanner(System.in);



    public void menu(){
        System.out.println("ingrese la opocion (ingrese 0 para salir):" +
                "\n1. cuadrado " +
                "\n2. rectangulo" +
                "\n3. traingulo (solamente equilatero)" +
                "\n4. circulo" +
                "\n5. hexagono" +
                "\n6. pentagono" +
                "\n7. rombo");
        int opcion = leer.nextInt();

        while (opcion!=0){
            switch (opcion){
                case 1 -> {
                    ServCuadrado sc = new ServCuadrado();
                    Cuadrado c = sc.crearCuadrado();
                    sc.area(c);
                    sc.perimetro(c);

                }
                case 2 ->{
                    ServRectangulo sr = new ServRectangulo();
                    Rectangulo r = sr.crearRectang();
                    sr.area(r);
                    sr.perimetro(r);

                }
                case 3 ->{
                    ServTriangulo st = new ServTriangulo();
                    Triangulo t = st.crearTriangulo();
                    st.area(t);
                    st.perimetro(t);
                }
                case 4 ->{
                    ServCirculo sc = new ServCirculo();
                    Circulo c = sc.crearCirculo();
                    sc.area(c);
                    sc.perimetro(c);

                }
                default -> System.out.println("error!");

            }
            System.out.println("ingrese  nuevamente la opcion (ingrese 0 para salir): ");
            opcion = leer.nextInt();
        }

        System.out.println("Hasta luego!");

    }


}

package Servicio;

import Entidad.Circulo;

import java.util.Scanner;

public class ServCirculo {
    Scanner leer = new Scanner(System.in);

    public Circulo  crearCirculo (){
        Circulo  c = new Circulo ();

        System.out.println("ingrese el radio: ");
        c.setRadio(leer.nextDouble());

        return c;
    }

    public void area(Circulo  c){
        System.out.println("el area del circulo es "+ Math.PI * (c.getRadio() * c.getRadio()));
    }

    public void perimetro(Circulo  c){
        System.out.println("El perimetro es " + Math.PI*2 * c.getRadio() );
    }
}

package Servicio;

import Entidad.Rectangulo;

import java.util.Scanner;

public class ServRectangulo {
    Scanner leer = new Scanner(System.in);

    public Rectangulo crearRectang(){
        Rectangulo c = new Rectangulo();

        System.out.println("ingrese el base: ");
        c.setBase(leer.nextDouble());
        System.out.println("ingrese el altura: ");
        c.setAltura(leer.nextDouble());
        return c;
    }

    public void area(Rectangulo c){
        System.out.println("el area del rectangulo es "+ c.getBase() * c.getAltura());
    }

    public void perimetro(Rectangulo c){
        System.out.println("El perimetro es " + (c.getBase()*2 + c.getAltura()*2) );
    }
}

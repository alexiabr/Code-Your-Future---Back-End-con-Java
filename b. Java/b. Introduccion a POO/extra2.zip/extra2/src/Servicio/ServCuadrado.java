package Servicio;

import Entidad.Cuadrado;

import java.util.Scanner;

public class ServCuadrado {
    Scanner leer = new Scanner(System.in);

    public Cuadrado crearCuadrado(){
        Cuadrado c = new Cuadrado();

        System.out.println("ingrese el lado: ");
        c.setLado(leer.nextDouble());
        return c;
    }

    public void area(Cuadrado c){
        System.out.println("el area del cuadrado es"+ c.getLado() * c.getLado());
    }

    public void perimetro(Cuadrado c){
        System.out.println("El perimetro es " + c.getLado()*4);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicio;

import Entidad.Rutina;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Iara
 */
public class RutinaServicio {

    private final Scanner leer = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");
    ArrayList<Rutina> rutinas = new ArrayList();
    private int id = -1;

    public void crearRutina() {
        Rutina r1 = new Rutina();
        
        ingresoDatos(r1);
        generarId(r1);

        rutinas.add(r1);
    }

    public void generarId(Rutina r1) {
        r1.setId(++id);
    }

    public void ingresoDatos(Rutina r1) {
        System.out.println("Ingrese nombre de la rutina");
        r1.setNombre(leer.next());
        System.out.println("Ingrese duracion");
        r1.setDuracion(leer.nextInt());
        System.out.println("Ingrese nivel de dificultad");
        r1.setNivelDificultad(leer.nextInt());
        System.out.println("Ingrese descripcion");
        r1.setDescripcion(leer.next());
    }

    public void obtenerRutinas() {

        for (Rutina r : rutinas) {
            System.out.println(r.toString());
        }

    }

     public void actualizarRutina(){
        obtenerRutinas();
        Rutina r1 = new Rutina();
        
        System.out.println("");
        System.out.println("Ingrese la rutina para actualizar");
        int numRutina = leer.nextInt();

        ingresoDatos(r1);
        r1.setId(numRutina);
        
        rutinas.set(numRutina, r1);
    }
    
    public void eliminarRutina(){
        obtenerRutinas();
        
        System.out.println("");
        System.out.println("Ingrese la rutina para borrar");
        int numRutina = leer.nextInt();

        rutinas.remove(numRutina);
    }
}

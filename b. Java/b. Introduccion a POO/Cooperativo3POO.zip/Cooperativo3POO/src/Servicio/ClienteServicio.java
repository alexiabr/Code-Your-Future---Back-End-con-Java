/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicio;

import Entidad.Cliente;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Iara
 */
public class ClienteServicio {
    private final Scanner leer = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");
    private int id = -1;
    ArrayList <Cliente> clientes = new ArrayList();

    public void registrarCliente() {
        Cliente c1 = new Cliente();

        generarId(c1);
        ingresoDatos(c1);

        clientes.add(c1);
    }

    public void ingresoDatos(Cliente c1){
        System.out.println("Ingrese nombre");
        c1.setNombre(leer.next());
        System.out.println("Ingrese edad");
        c1.setEdad(leer.nextInt());
        System.out.println("Ingrese altura");
        c1.setAltura(leer.nextDouble());
        System.out.println("Ingrese peso");
        c1.setPeso(leer.nextDouble());
        System.out.println("Ingrese objetivo");
        c1.setObjetivo(leer.next());
    }
    
    public void generarId(Cliente c1) {
        c1.setId(++id);
    }

    public void obtenerClientes() {

        for (Cliente c : clientes) {
            System.out.println(c.toString());
        }

    }

    public void actualizarCliente(){
        obtenerClientes();
        Cliente c1 = new Cliente();
        
        System.out.println("");
        System.out.println("Ingrese el cliente para actualizar");
        int numCliente = leer.nextInt();

        ingresoDatos(c1);
        c1.setId(numCliente);
        
        clientes.set(numCliente, c1);
    }
    
    public void eliminarCliente(){
        obtenerClientes();
        
        System.out.println("");
        System.out.println("Ingrese el cliente para borrar");
        int numCliente = leer.nextInt();

        clientes.remove(numCliente);
    }

}

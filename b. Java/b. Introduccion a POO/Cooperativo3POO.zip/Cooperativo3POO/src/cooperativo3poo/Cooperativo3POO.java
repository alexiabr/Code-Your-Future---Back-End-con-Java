/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cooperativo3poo;

import Servicio.ClienteServicio;
import Servicio.RutinaServicio;
import java.util.Scanner;

/**
 *
 * @author Iara
 */
public class Cooperativo3POO {

    private final static Scanner leer = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        ClienteServicio cs = new ClienteServicio();
        for(int i=0; i<5; i++){
            cs.registrarCliente();
        }
        System.out.println("\nLista de clientes: ");
        cs.obtenerClientes();
        System.out.println("");
        cs.actualizarCliente();
        System.out.println("\nLista de clientes actualizada: ");
        cs.obtenerClientes();
        System.out.println("");
        cs.eliminarCliente();
        System.out.println("\nLista de clientes actualizada: ");
        cs.obtenerClientes();
       
        
        RutinaServicio rs = new RutinaServicio();
        for(int i=0; i<5; i++){
            rs.crearRutina();
        }
        System.out.println("\nLista de rutinas: ");
        rs.obtenerRutinas();
        System.out.println("");
        rs.actualizarRutina();
        System.out.println("\nLista de rutinas actualizadas: ");
        rs.obtenerRutinas();
        System.out.println("");
        rs.eliminarRutina();
        System.out.println("\nLista de rutinas actualizadas: ");
        rs.obtenerRutinas();
         */
        int opc;
        ClienteServicio cs = new ClienteServicio();
        RutinaServicio rs = new RutinaServicio();

        do {
            System.out.println("Menu");
            System.out.println("1- Agregar cliente");
            System.out.println("2- Actualizar cliente");
            System.out.println("3- Eliminar cliente");
            System.out.println("4- Mostrar cliente");
            System.out.println("5- Agregar Rutina");
            System.out.println("6- Actualizar Rutina");
            System.out.println("7- Eliminar Rutina");
            System.out.println("8- Mostrar Rutina");
            System.out.println("9- Salir");
            opc = leer.nextInt();

            switch (opc) {
                case 1:
                    cs.registrarCliente();
                    break;
                case 2:
                    cs.actualizarCliente();
                    break;
                case 3:
                    cs.eliminarCliente();
                    break;
                case 4:
                    cs.obtenerClientes();
                    break;
                case 5:
                    rs.crearRutina();
                    break;
                case 6:
                    rs.actualizarRutina();
                    break;
                case 7:
                    rs.eliminarRutina();
                    break;
                case 8:
                    rs.obtenerRutinas();
                    break;
                case 9:
                    System.out.println("Muchas Gracias");
                default:
                    System.out.println("Error");
            }
        } while (opc != 9);

    }

}
